$(document).ready(function(){
    function setheight() {
      var windowheight = window.innerHeight;
      var bodyheight = windowheight;
      var headerheight = $('.header').outerHeight();
      var footerheight = $('.footer').outerHeight();
      var mainbodyheight = bodyheight - footerheight - headerheight;
      $('.main-body').css({
        'min-height': mainbodyheight + 'px'
      });
      $('.content').css({
        'min-height': mainbodyheight + 'px'
      });
    }

    setheight();
    $(window).resize(function() {
      setheight();
    });

    jQuery('.menu-btn').click(function(){
      if (jQuery('body').hasClass("menu-clicked")){
          jQuery('body').removeClass("menu-clicked");
        }
        else{
          jQuery('body').addClass("menu-clicked");
        }
      }
    );

    $('#flexRadioDefault2').click(function () {
      $('#flexRadioDefault2').parents('.left-sec').addClass("tab2");
      $("#signin-form").attr("action", "/check-driver")
      $("#signup-form").attr("action", "/add-driver")

      $("#name1").attr("name","name1")
      $("#username1").attr("name","username1")
      $("#password1").attr("name","password1")
      $("#phone1").attr("name","phone1")
      $("#email1").attr("name","email1")

      $("#name2").attr("name","name")
      $("#username2").attr("name","username")
      $("#password2").attr("name","password")
      $("#phone2").attr("name","phone")
      $("#email2").attr("name","email")


      $("#username3").attr("name","username1")
      $("#password3").attr("name","password1")

      $("#username4").attr("name","username")
      $("#password4").attr("name","password")


    });  

    $('#flexRadioDefault1').click(function () {
      $('#flexRadioDefault1').parents('.left-sec').removeClass("tab2");
      $("#signin-form").attr("action", "/login-user")
      $("#signup-form").attr("action", "/add-user")

      $("#name2").attr("name","name1")
      $("#username2").attr("name","username1")
      $("#password2").attr("name","password1")
      $("#phone2").attr("name","phone1")
      $("#email2").attr("name","email1")

      $("#name1").attr("name","name")
      $("#username1").attr("name","username")
      $("#password1").attr("name","password")
      $("#phone1").attr("name","phone")
      $("#email1").attr("name","email")

	  $("#username4").attr("name","username1")
      $("#password4").attr("name","password1")

      $("#username3").attr("name","username")
      $("#password3").attr("name","password")
    });

});


// forms
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()


// Tooltip
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
});

// popover
var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
  return new bootstrap.Popover(popoverTriggerEl)
})