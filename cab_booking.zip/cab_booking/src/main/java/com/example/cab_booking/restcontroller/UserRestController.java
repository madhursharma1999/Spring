package com.example.cab_booking.restcontroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.cab_booking.entities.User;
import com.example.cab_booking.service.UserService;

@RestController
public class UserRestController {
	
	@Autowired    
	private UserService userServiceLayer;
	
	@RequestMapping("/admin/get-all-user")
	public String getAllUserAdmin() {
		
		List<User> users = userServiceLayer.getUserAdmin();
		
		String res="<style>"
				+ " th, td {"
				+ "  border:1px solid black;"
				+ "  padding-top: 10px;"
				+ "  padding-bottom: 20px;"
				+ "  padding-left: 30px;"
				+ "  padding-right: 40px;"
				+ "}"
				+ "</style>"
				+ "<table>";
		 for (User user : users) {
			 
	            // Print all elements of ArrayList
			 res+="<tr><td>"+user.getUid()+"</td><td>"+user.getName()+"</td><td>"+user.getEmail()+"</td><td>"+user.getPhone()+"</td><td>"+user.getRating()+"</td></tr>";
	            
	        }
		res+="</table> <br><br><a href='/logout'><button>Logout</button></a>";
		return res;
		
	}
	
	@RequestMapping("/user/get-all-user")
	public ArrayList<ArrayList<String>> getAllUser() {
		
		return userServiceLayer.getUser();
	}

}
